<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buyer Login</title>
    <link rel="stylesheet" href="styles1.css">
</head>
<body>
    <div class="container">
        <h2>Buyer Login</h2>
        <form action="buyer_login_process.php" method="post">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            
            <div class="button-group">
                <input type="submit" value="Login">
                <input type="reset" value="Reset">
            </div>
        </form>
        <p>Don't have an account? <a href="buyer_register.php">Sign Up</a></p>
        <a href="index.html" class="back-button">Back</a>
    </div>
</body>
</html>
