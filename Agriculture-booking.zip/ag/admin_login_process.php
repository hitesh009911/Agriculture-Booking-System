<?php
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "fb";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get username and password from the login form
$username = $_POST['username'];
$password = $_POST['password'];

// SQL query to check if the admin exists
$sql = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
$result = $conn->query($sql);

// Check if the query returned any rows
if ($result->num_rows > 0) {
    // Admin exists, set session variables and redirect to admin dashboard
    $_SESSION['admin_logged_in'] = true;
    header("Location: admin_dashboard.php"); // Redirect to the admin dashboard
} else {
    // Admin doesn't exist, redirect back to the login page with an error message
    header("Location: admin_login.php?error=invalid_credentials");
}

// Close connection
$conn->close();
?>
