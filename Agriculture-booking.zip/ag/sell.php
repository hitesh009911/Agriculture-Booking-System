<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product to Sell</title>
    <style>
        /* Add your CSS here */
        * {
            box-sizing: border-box; /* Include padding and border in element's total width and height */
        }

        body {
            font-family: Arial, sans-serif; /* Use a common font */
            background-color: #f0f0f0; /* Use a light background color */
        }

        h2 {
            text-align: center; /* Center the heading */
            color: #4CAF50; /* Use a green color */
            margin-top: 20px; /* Add some top margin */
        }

        form {
            max-width: 600px; /* Set a maximum width for the form */
            margin: 0 auto; /* Center the form */
            padding: 20px; /* Add some padding */
            background-color: white; /* Use a white background color */
            border: 1px solid #ccc; /* Add a gray border */
            border-radius: 10px; /* Make the corners rounded */
        }

        label {
            display: block; /* Make the label take up the whole width */
            margin-bottom: 10px; /* Add some bottom margin */
        }

        input, select, textarea {
            display: block; /* Make the input, select, and textarea take up the whole width */
            width: 100%; /* Set the width to 100% */
            padding: 10px; /* Add some padding */
            border: 1px solid #ccc; /* Add a gray border */
            border-radius: 5px; /* Make the corners rounded */
        }

        input[type="submit"], input[type="reset"], button {
            display: inline-block; /* Make the buttons take up only as much space as they need */
            width: auto; /* Set the width to auto */
            margin-right: 10px; /* Add some right margin */
            background-color: #4CAF50; /* Use a green background color */
            color: white; /* Use a white text color */
            border: none; /* Remove the border */
            border-radius: 5px; /* Make the corners rounded */
            cursor: pointer; /* Change the cursor to a pointer */
        }

        input[type="submit"]:hover, input[type="reset"]:hover, button:hover {
            background-color: #3a8d40; /* Use a darker green color on hover */
        }

        input:focus, select:focus, textarea:focus {
            outline: none; /* Remove the default outline */
            box-shadow: 0 0 5px #4CAF50; /* Add a green shadow effect */
        }
    </style>
</head>
<body>
    <h2>Add Product to Sell</h2>
    <form action="process_sell.php" method="post">
        <label for="product_type">Product Type:</label><br>
        <select id="product_type" name="product_type" required>
            <option value="fertilizers">Fertilizers</option>
            <option value="pesticides">Pesticides</option>
        </select><br><br>

        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name" required><br><br>

        <label for="description">Description:</label><br>
        <textarea id="description" name="description" rows="4"></textarea><br><br>

        <label for="price">Price:</label><br>
        <input type="text" id="price" name="price" required><br><br>

        <input type="submit" value="Add Product">
		 <input type="reset" value="Reset">	
    </form>
	<br>
	<center> <a href="sup.html"><button>Back</button></a>
</body>
</html>
