<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "fb"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];

// Check if username already exists
$sql_check = "SELECT * FROM suppliers WHERE username='$username'";
$result_check = $conn->query($sql_check);

if ($result_check->num_rows > 0) {
    // Username already exists, redirect back with error
    header("Location: register.php?error=user_exists");
    exit();
} else {
    // Insert new supplier into database
    $sql_insert = "INSERT INTO suppliers (username, password) VALUES ('$username', '$password')";

    if ($conn->query($sql_insert) === TRUE) {
        // Registration successful, redirect to login page
        header("Location: sup.html");
        exit();
    } else {
        echo "Error: " . $sql_insert . "<br>" . $conn->error;
    }
}

$conn->close();
?>
