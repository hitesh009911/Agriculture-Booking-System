<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "fb"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];

// Check if username already exists
$sql_check = "SELECT * FROM buyers WHERE username='$username'";
$result_check = $conn->query($sql_check);

if ($result_check->num_rows > 0) {
    // Username already exists, redirect back with error
    header("Location: buyer_register.php?error=user_exists");
    exit();
} else {
    // Insert new buyer into database
    $sql_insert = "INSERT INTO buyers (username, password) VALUES ('$username', '$password')";

    if ($conn->query($sql_insert) === TRUE) {
        header("Location: buyer.php");
        exit();
    } else {
        echo "Error: " . $sql_insert . "<br>" . $conn->error;
    }
}

$conn->close();
?>
