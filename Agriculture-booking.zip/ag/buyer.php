<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buyer Page</title>
    <style>
      body {
    font-family: Arial, sans-serif;
    background-color: #f8f8f8;
    margin: 0;
    padding: 20px;
}

h2 {
    color: #333;
}

.info-box {
    border: 1px solid #ccc;
    padding: 20px;
    margin-bottom: 20px;
    position: relative;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.info-box h3 {
    margin-top: 0;
    color: #333;
}

.info-box p {
    margin-bottom: 10px;
    color: #666;
}

.info-box img {
    max-width: 100%;
    display: block;
    margin-top: 10px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    background-color: #fff;
    border: 1px solid #ccc;
}

table th, table td {
    padding: 10px;
    border-bottom: 1px solid #ccc;
    text-align: left;
}

table th {
    background-color: #f2f2f2;
    color: #333;
}

table tr:hover {
    background-color: #f2f2f2;
}

button {
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    padding: 10px 20px;
    cursor: pointer;
    transition: background-color 0.3s;
}

button:hover {
    background-color: #0056b3;
}

a {
    color: #007bff;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

    </style>
</head>
<body>
    <h2>Welcome, Buyer!</h2>

    <!-- Info Box for Fertilizers -->
    <div class="info-box" style="background-image: url('fertilizers_image.jpg');">
        <h3>Fertilizers</h3>
        <p>Buy high-quality fertilizers to boost the growth of your plants and crops.</p>
        <p><a href="https://en.wikipedia.org/wiki/Fertilizer" target="_blank">Learn more about fertilizers on Wikipedia</a></p>
        <img src="f.jpeg" alt="Fertilizers Image">
    </div>

    <!-- Info Box for Pesticides -->
    <div class="info-box" style="background-image: url('pesticides_image.jpg');">
        <h3>Pesticides</h3>
        <p>Keep your plants and crops protected from pests with our effective pesticides.</p>
        <p><a href="https://en.wikipedia.org/wiki/Pesticide" target="_blank">Learn more about pesticides on Wikipedia</a></p>
        <img src="p.jpeg" alt="Pesticides Image">
    </div>
    
    <?php
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "fb"; // Replace with your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch products from the database
    $sql = "SELECT * FROM products";
    $result = $conn->query($sql);

    // Check if there are any products
    if ($result->num_rows > 0) {
        echo "<h2>Available Products:</h2>";
        echo "<table border='1'>";
        echo "<tr><th>ID</th><th>Product Type</th><th>Name</th><th>Description</th><th>Price</th><th>Action</th></tr>";
        
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["id"] . "</td>";
            echo "<td>" . $row["product_type"] . "</td>";
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["description"] . "</td>";
            echo "<td>" . $row["price"] . "</td>";
            echo "<td><button onclick='showOrderForm(" . $row['id'] . ")'>Buy</button></td>";
            echo "</tr>";
            echo "<tr style='display: none;' id='form-row-" . $row['id'] . "'><td colspan='6'>";
            echo "<form id='order-form-" . $row['id'] . "' class='order-form' action='process_order.php' method='post'>";
            echo "<input type='hidden' name='product_id' value='" . $row['id'] . "'>";
            echo "Quantity: <input type='number' name='quantity' min='1' required><br>"; // Minimum value set to 1
            echo "Mode of Payment: <input type='text' name='mode_of_payment' required><br>";
            echo "Customer Name: <input type='text' name='customer_name' required><br>";
            echo "Customer Email: <input type='email' name='customer_email' required><br>";
            echo "<input type='submit' value='Place Order'>";
            echo "<input type='reset' value='Reset'>";
            echo "</form>";
            echo "</td></tr>";
        }
        
        echo "</table>";
    } else {
        echo "No products available.";
    }

    // Close connection
    $conn->close();
    ?>

    <script>
        function showOrderForm(productId) {
            var formRow = document.getElementById('form-row-' + productId);
            formRow.style.display = formRow.style.display === 'none' ? 'table-row' : 'none';
        }
    </script>

    <p><a href="log_out.php">Logout</a></p> <!-- Logout link -->
</body>
</html>
