<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "fb"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve order details from the form
    $product_id = $_POST["product_id"];
    $quantity = $_POST["quantity"];
    $mode_of_payment = $_POST["mode_of_payment"];
    $customer_name = $_POST["customer_name"];
    $customer_email = $_POST["customer_email"];

    // Fetch product price from the database
    $sql_product = "SELECT price FROM products WHERE id='$product_id'";
    $result_product = $conn->query($sql_product);

    if ($result_product->num_rows > 0) {
        $row_product = $result_product->fetch_assoc();
        $price = $row_product["price"];

        // Calculate total price
        $total_price = $price * $quantity;

        // Insert order into the database
        $sql_order = "INSERT INTO orders (product_id, quantity, total_price, mode_of_payment, customer_name, customer_email) VALUES ('$product_id', '$quantity', '$total_price', '$mode_of_payment', '$customer_name', '$customer_email')";

        if ($conn->query($sql_order) === TRUE) {
            // Output success message and total price
            echo "Order placed successfully. Total Price: $total_price";

            // Add a back button
            echo "<br><br><button onclick='goBack()'>Back</button>";

            // JavaScript function to go back to the previous page
            echo "<script>";
            echo "function goBack() {";
            echo "window.history.back();";
            echo "}";
            echo "</script>";
        } else {
            echo "Error placing order: " . $conn->error;
        }
    } else {
        echo "Product not found.";
    }
} else {
    echo "Invalid request.";
}

// Close connection
$conn->close();
?>
