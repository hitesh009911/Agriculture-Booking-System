hey there

db folder db file named fb 
just go to xampp php admin there u shall import option click place this file ur db job is done 

supplier usernm zack 
ps 123

buyer usernm zack
ps 123

admin usrnm admin
ps 123

