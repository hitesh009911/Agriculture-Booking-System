<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$database = "fb"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM suppliers WHERE username='$username' AND password='$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Login successful, store username in session and redirect to dashboard
    $_SESSION['username'] = $username;
    header("Location: sup.html");
    exit();
} else {
    echo "Invalid username or password.";
}

$conn->close();
?>
