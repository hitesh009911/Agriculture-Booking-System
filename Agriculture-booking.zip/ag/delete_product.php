<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "fb"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve product ID from the form
    $id = $_POST["id"];

    // Delete product from the database
    $sql = "DELETE FROM products WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "Product deleted successfully. Redirecting back to the page soon";
    } else {
        echo "Error deleting product: " . $conn->error;
    }
    
    // Redirect back to the orders page after deletion
    header("Location: order.php");
    exit;
} else {
    echo "Invalid request.";
}

// Close connection
$conn->close();
?>
