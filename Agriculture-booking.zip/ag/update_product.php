<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "fb"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve product ID and updated details from the form
    $id = $_POST["id"];
    $product_type = $_POST["product_type"];
    $name = $_POST["name"];
    $description = $_POST["description"];
    $price = $_POST["price"];

    // Update product in the database
    $sql = "UPDATE products SET product_type='$product_type', name='$name', description='$description', price='$price' WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        // Redirect back to the orders page after updating
        header("Location: order.php");
        exit;
    } else {
        echo "Error updating product: " . $conn->error;
    }
} else {
    // Retrieve product ID from URL parameter
    $id = $_GET["id"];

    // Fetch product details from the database
    $sql = "SELECT * FROM products WHERE id='$id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $product_type = $row["product_type"];
        $name = $row["name"];
        $description = $row["description"];
        $price = $row["price"];
    } else {
        echo "Product not found.";
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Product</title>
</head>
<style>
* {
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
}

h2 {
    text-align: center;
    color: #4CAF50;
    margin-top: 20px;
}

form {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
    background-color: white;
    border: 1px solid #ccc;
    border-radius: 10px;
}

label {
    display: block;
    margin-bottom: 10px;
}

input, textarea {
    display: block;
    width: calc(100% - 20px);
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

textarea {
    resize: vertical;
}

input[type="submit"], input[type="reset"], button {
    display: inline-block;
    margin-right: 10px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 10px;
    cursor: pointer;
}

input[type="submit"]:hover, input[type="reset"]:hover, button:hover {
    background-color: #3a8d40;
}

input:focus, textarea:focus {
    outline: none;
    box-shadow: 0 0 5px #4CAF50;
}

a {
    text-decoration: none;
    color: #007bff;
}

a:hover {
    text-decoration: underline;
}

</style>
<body>
    <h2>Update Product</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <label for="product_type">Product Type:</label><br>
        <input type="text" id="product_type" name="product_type" value="<?php echo $product_type; ?>" required><br><br>

        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name" value="<?php echo $name; ?>" required><br><br>

        <label for="description">Description:</label><br>
        <textarea id="description" name="description" rows="4"><?php echo $description; ?></textarea><br><br>

        <label for="price">Price:</label><br>
        <input type="text" id="price" name="price" value="<?php echo $price; ?>" required><br><br>

        <input type="submit" value="Update Product">
		<input type="reset" value="Reset">	
    </form>
	<br>
	
		 <center><a href="order.php"><button>Back</button></a>
</body>
</html>
