<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            width: 400px;
            text-align: center;
        }

        h1 {
            margin-top: 0;
            color: #333;
            font-size: 24px;
            margin-bottom: 20px;
        }

        a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
            margin-right: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f2f2f2;
        }

        .logout-btn {
            background-color: #dc3545;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 20px;
            text-decoration: none;
        }

        .logout-btn:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Admin Dashboard</h1>
        <a href="admin_dashboard.php?view=suppliers">View Suppliers</a>
        <a href="admin_dashboard.php?view=buyers">View Buyers</a>

        <?php
        // Check if admin is logged in, if not, redirect to login page
        session_start();
        if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
            header("Location: admin_login.php");
            exit;
        }

        // Database connection parameters
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "fb";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $database);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Check if suppliers or buyers button is clicked
        if (isset($_GET['view'])) {
            $view = $_GET['view'];

            if ($view === 'suppliers') {
    // Fetch suppliers from the database
    $sql = "SELECT * FROM suppliers";
    $result = $conn->query($sql);

    // Check if there are any suppliers
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>ID</th><th>Username</th></tr>";

        // Output data of each supplier
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["id"] . "</td>";
            echo "<td>" . $row["username"] . "</td>"; // Change "name" to "username"
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "No suppliers available.";
    }
} elseif ($view === 'buyers') {
    // Fetch buyers from the database
    $sql = "SELECT * FROM buyers";
    $result = $conn->query($sql);

    // Check if there are any buyers
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>ID</th><th>Username</th></tr>";

        // Output data of each buyer
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["id"] . "</td>";
            echo "<td>" . $row["username"] . "</td>"; // Change "name" to "username"
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "No buyers available.";
    }
}

        }

        // Close connection
        $conn->close();
        ?>

       <br>
<br>	   <a href="admin_logout.php" class="logout-btn">Logout</a>
    </div>
</body>
</html>
