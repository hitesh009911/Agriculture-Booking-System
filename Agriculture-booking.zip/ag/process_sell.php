<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "fb"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $product_type = $_POST["product_type"];
    $name = $_POST["name"];
    $description = $_POST["description"];
    $price = $_POST["price"];

    // Perform validation (you can add more validation as needed)

    // Insert product into database
    $sql = "INSERT INTO products (product_type, name, description, price) VALUES ('$product_type', '$name', '$description', '$price')";

    if ($conn->query($sql) === TRUE) {
        echo "Product added successfully. Redirecting back to the form page soon";
        // Redirect back to the form page after 3 seconds
        header("refresh:3;url=sell.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    // If the form is not submitted, redirect back to the form page
    header("Location: sell.php");
    exit;
}

// Close connection
$conn->close();
?>
