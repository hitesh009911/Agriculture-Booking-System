<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "fb"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch products from the database
$sql = "SELECT * FROM products";
$result = $conn->query($sql);

// Check if there are any products
if ($result->num_rows > 0) {
    echo "<h2>Available Products:</h2>";
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Product Type</th><th>Name</th><th>Description</th><th>Price</th><th>Actions</th></tr>";
    
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . $row["product_type"] . "</td>";
        echo "<td>" . $row["name"] . "</td>";
        echo "<td>" . $row["description"] . "</td>";
        echo "<td>" . $row["price"] . "</td>";
        echo "<td>";
        // View button
        echo "<a href='view_orders.php?id=" . $row['id'] . "'>View</a> | ";
        // Update button
        echo "<a href='update_product.php?id=" . $row['id'] . "'>Update</a> | ";
        // Delete form
        echo "<form action='delete_product.php' method='post' style='display: inline;'>
                    <input type='hidden' name='id' value='" . $row["id"] . "'>
                    <input type='submit' value='Delete'>
              </form>";
        echo "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
} else {
    echo "No products available.";
}

// Close connection
$conn->close();
?>
